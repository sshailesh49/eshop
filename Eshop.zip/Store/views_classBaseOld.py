
from urllib import request
from django.shortcuts import render,redirect,get_object_or_404
from django.http import HttpResponse
from .models.product import Product
from .models.category import Category
from.models.customer import Customer
from django.contrib.auth.hashers import make_password,check_password
from django.views import View

# Create your views here.

def home(request):
    #allproduct=Product.get_all_data()
    allcategory=Category.all_category_list()
    categoryID=request.GET.get('category')
    print(categoryID)
    
    if categoryID:
        allproduct=Product.get_all_data_by_categoryid(categoryID)
    else:
        allproduct=Product.get_all_data()
   
    
    
    return render(request,"index.html",{'products':allproduct,'categorys':allcategory})



    
        
class Login(View):
  
    
    def get(self,request):
        return render(request,'login.html')
    
    def post(self,request):
        user=request.POST.get('email')
        password=request.POST.get('password')
        
        customer=Customer.customer_data_by_email(user)
        error_message=None
        if customer.exists:
            print(customer)
            print(customer[0])
            
            flag=check_password(password,customer[0].password)
            if flag==True:
                return redirect('home')
            else:
                error_message="Email ok But Password is Wrong"
                return render(request,'login.html',{'error':error_message})
            
class Signup(View):
    
    def get(self,request):
        return render(request,'signup.html')
    
    def registration(self,request):   
        firstname=request.POST.get('fname')
        lastname=request.POST.get('lname')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        password=request.POST.get('password')
        
        values={'firstname':firstname,
                'lastname':lastname,
                'email':email,
                'phone':phone,
                }
        customer=Customer(first_name=firstname,last_name=lastname,email=email,phone=phone,password=password)
        error_message=self.validation_customer(customer)
        
        
        print(error_message)
        
        if  not error_message:
            
        
            
            #customer.save()
            
            customer.password=make_password(customer.password)
            customer.register()
            success_message="Account sucessfull Created!!"
            return render(request,'signup.html',{'message':success_message})
        else:
            
            return render(request,'signup.html',{'error':error_message,'value':values})
        
    def validation_customer(self,customer):
        #validation
        error_message=None
        if not customer.first_name:
            error_message="First name Required!!"
        elif len(customer.first_name)<4:
            error_message="First name must be long 4 char and above"
        elif not customer.last_name:
            error_message="Last Name Required!!"
        elif len(customer.last_name)<4:
            error_message="Last name must be long 4 char and above"
            
            
        elif not customer.email:
            error_message="Email Required!!"
        elif not customer.phone:
            error_message="Phone Required!!"
        elif len(customer.phone)<10:
            error_message="phone must be long 10 digits and above"
        elif not customer.password:
            error_message="Password  Required!!"
        elif len(customer.password)<8:
            error_message="Password must be long 8 char and above"
        elif customer.is_exist():
            print(customer.is_exist())
            error_message="Email address Already exist!!"
        return error_message
                  
    def post(self,request):  
    
        return self.registration(request)      
                
                
            
        
        
       
    
       
   
    