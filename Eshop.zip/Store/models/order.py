from django.db import models
from Store.models.customer import Customer
from Store.models.product import Product
from datetime import datetime
from django.utils.timezone import now

#
class Order(models.Model):
    customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    product=models.ForeignKey(Product,on_delete=models.CASCADE)
    quantity=models.IntegerField(default=0)
    price=models.IntegerField(default=0)
    phone=models.CharField(max_length=12,default='',blank=True)
    address=models.CharField(max_length=100,default='',blank=True)
    date=models.DateTimeField(default=datetime.now,null=True)
    
    order_status=models.BooleanField(default=False)

