
from django.db import models

from .category import Category
class Product(models.Model):
    name=models.CharField(max_length=50)
    category=models.ForeignKey(Category,on_delete=models.CASCADE,default=1)
    price=models.IntegerField(default=0)
    description=models.CharField(max_length=200,default='',null=True,blank=True)
    image=models.ImageField(upload_to='media/products/')
    
    
    
    
    
    
    @staticmethod
    def get_all_data():
        allproduct=Product.objects.all()
        return allproduct
    
    @staticmethod
    def get_all_data_by_categoryid(cateid):
        if cateid is not None:
           allproductbycategory=Product.objects.filter(category=cateid) 
           return allproductbycategory
        else:
            allproduct=Product.get_all_data()
            return allproduct
        
   
    