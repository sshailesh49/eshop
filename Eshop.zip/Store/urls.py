
from django.contrib import admin
from django.urls import path

from Store.models.order import Order
#from . import views_classBaseOld
from .views import home,myorder
from .views import login,signup,mycart,checkout
from Store.middlewares.auth_middleware import auth_middlewares

# urlpatterns = [
#     path('',views_classBaseOld.home,name='home'),
#     path('signup',views_classBaseOld.Signup.as_view()),
#     path('login',views_classBaseOld.Login.as_view()),
# ]
urlpatterns = [
    path('',home.Home.as_view(),name='home'),
    path('login',login.Login.as_view(),name='login'),
    path('signup',signup.Signup.as_view(),name='signup'),
    path('signout',login.signout,name='signout'),
    path('cart',mycart.Cart.as_view(),name="cart"),
    path('checkout',checkout.CheckOut.as_view(),name='checkout'),
    path('orders',auth_middlewares(myorder.Order.as_view()),name="orders"),
    
    
    
]
