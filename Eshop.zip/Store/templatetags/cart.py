from atexit import register
from django import template

register=template.Library()

#------

@register.filter(name="is_in_cart")
def is_in_cart(product,cart):
 
    keys=cart.keys()
    key=list(keys)

    for i in key:
       # print("i value",i)
        if int(i)==product.id:
          # print("true")
           return True
        
    return False

@register.filter(name="cart_in_value")
def cart_in_value(product,cart):
    for k,v in cart.items():
        if int(k)==product.id:
            return int(v)
    return 0       
 
@register.filter(name="total_price")
def total_price(product,cart):
    for k,v in cart.items():
        
        
        if int(k)==product.id:
            #print(product.price*v)
            return int(product.price)*v
      

@register.filter(name="total_cart_price")
def total_cart_price(products,cart):
    print("start")
    sum=0
    for p in products:
        
        print(total_price(p,cart))
        sum =sum+total_price(p,cart)
        
        
    return sum   

@register.filter(name="currency")
def currency(number):
    return '₹' +' '+str(number)

@register.filter(name="order_total")
def order_total(number,number2):
    return number*number2