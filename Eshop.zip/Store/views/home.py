
from django.shortcuts import render,redirect

from Store.models.category import Category
from Store.models.product import Product
from django.views import View

#view

class Home(View):
    
    def get(self,request):
        
        cus_id=request.session.get('id')
        print("sessionid",cus_id)
        email=request.session.get('email')
        print('session email',email)
        
        first_name=request.session.get('first_name')
        print('session email',first_name)
        
        category=Category.all_category_list()
        id=request.GET.get('category')
        #print("getid",id)
        if id is not None:
           product=Product.get_all_data_by_categoryid(id)
        else:
           product=Product.get_all_data()
            
        return render(request,'index.html',{'categorys':category,'products':product,'user':first_name})
         
    def post(self,request):
      product_id=request.POST.get('productId')
      remove=request.POST.get('remove')
      cart=request.session.get('cart')
      print(cart)
      if cart:
              quintity=cart.get(product_id)
      
              if quintity:
                     
                     
                     if remove:
                            if quintity <=1:
                                   cart.pop(product_id)
                            else:       
                              cart[product_id]=quintity-1
                     else:
                            cart[product_id]=quintity+1
                 
              else:
                     cart[product_id]=1
                     
           
      else:
            cart={}
            cart[product_id]=1
      request.session['cart']=cart
      #
      print(cart)
       
       
      return redirect('home')