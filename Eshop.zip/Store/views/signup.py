

from django.shortcuts import render,redirect
from Store.models.customer import Customer
from Store.models.category import Category
from Store.models.product import Product 
from django.views import View
from django.contrib.auth.hashers import make_password,check_password


#----------------

class Signup(View):
    
    def get(self,request):
        return render(request,'signup.html')
    
    
    
    def registration(self,request):
        firstname=request.POST.get('fname')
        lastname=request.POST.get('lname')
        phone=request.POST.get('phone')
        email=request.POST.get('email')
        password=request.POST.get('password')
        
        values={'firstname':firstname,
                'lastname':lastname,
                'phone':phone,
                'email':email,
                
            
            
        }
        #error_message=None
        
        customer=Customer(first_name=firstname,last_name=lastname,phone=phone,email=email,password=password)
        error=self.error_validation(customer)
        if  error:
            return render(request,'signup.html',{'error':error,'value':values})
        else:
            customer.password=make_password(customer.password)
            
            customer.register()
            sucess_message="User create Successfully!!"
            return render(request,'signup.html',{'message':sucess_message})
        
        
        
    def error_validation(self,customer):
        
        error_message=None
        if not customer.first_name:
            error_message="First name Required!!"
        elif len(customer.first_name)<4:
            error_message="First name must be long 4 char and above"
        elif not customer.last_name:
            error_message="Last Name Required!!"
        elif len(customer.last_name)<4:
            error_message="Last name must be long 4 char and above"
            
            
        elif not customer.email:
            error_message="Email Required!!"
        elif not customer.phone:
            error_message="Phone Required!!"
        elif len(customer.phone)<10:
            error_message="phone must be long 10 digits and above"
        elif not customer.password:
            error_message="Password  Required!!"
        elif len(customer.password)<8:
            error_message="Password must be long 8 char and above"
        elif customer.is_exist():
            print(customer.is_exist())
            error_message="Email address Already exist!!"
        return error_message
               
    def post(self,request):
        return self.registration(request)