
from django.shortcuts import render,redirect,HttpResponseRedirect


from Store.models.customer import Customer

from django.views import View
from django.contrib.auth.hashers import check_password


#view

class Login(View):
      return_url=None
      
      def get(self,request):
             Login.return_url=request.GET.get('return_url')
             return render(request,'login.html')
          
      
      def loginpost(self,request):
             email=request.POST.get('email')
             password=request.POST.get('password')
             customer=Customer.customer_data_by_email(email)
             print(customer)
             error_message=None
             if customer:
                    customer=customer[0]
                    password=check_password(password,customer.password)
                    if password==True:
                           request.session['id']=customer.id
                           request.session['email']=customer.email
                           request.session['first_name']=customer.first_name
                           if Login.return_url:
                                  return HttpResponseRedirect(Login.return_url)
                                  
                           else:
                            return_url=None     
                            return redirect('home')
                    else:
                           error_message="Password Invalid Try Again!"
                           return render(request,'login.html',{'error':error_message})
             else:
                     error_message="Email Invalid Try Again!"
                     return render(request,'login.html',{'error':error_message})
                    
                           
                           
             
             
             
             
             
          
      
      def post(self,request):
             request.session.clear()
             return self.loginpost(request)
     
         
  
def signout(request):
       request.session.clear()
       return redirect('login')