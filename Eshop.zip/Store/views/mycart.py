from django.shortcuts import render,redirect
from django.views import View
from Store.middlewares.auth_middleware import auth_middlewares
from Store.models.product import Product
from django.utils.decorators import method_decorator

class Cart(View):
    @method_decorator(auth_middlewares)
    def get(self,request):
      ids=[]
      cart={}
      cart=request.session.get('cart')
      print("ghfhfghfhfhfh12424234",cart)
      if cart:
        ids=cart.keys()
        print(ids)
        product=Product.objects.filter(id__in=ids)
        return render(request,'cart.html',{'products':product})
      else:
        product=Product.objects.filter(id__in=ids)
        return render(request,'cart.html',{'products':product})
            
      
      
        
          
          
          
            
        