from django.shortcuts import render,redirect
from django.views import View
from Store.models.product import Product
from Store.models import customer, order


class Order(View):
    def get(self,request):
          
          
      #     if  'email' in request.session:

                email=request.session['email']
                
      #           print(email)
                myorder=order.Order.objects.filter(customer__email=email).order_by('-date')

               #myorder=order.Order.objects.all().order_by('-date')

                return render(request,'order.html',{'orders':myorder})
              
      #     else:
      #         return  redirect('login')
                
