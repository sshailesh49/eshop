from django.shortcuts import render,redirect
from django.views import View
from Store.models.product import Product
from Store.models.order import Order
from Store.models.customer import Customer


class CheckOut(View):
    def post(self,request):
        phone=request.POST.get('phone')
        address=request.POST.get("address")
        customer=request.session.get('id')
        print(type(customer))
        cart=request.session.get('cart')
        ids=cart.keys()
        print(ids)
        products=Product.objects.filter(id__in=ids)
        
        for product in products:
          order=Order(customer=Customer(id=customer),
                      product=product,
                      quantity=cart.get(str(product.id)),
                      price=product.price,
                      phone=phone,
                      address=address)
          order.save()
        request.session['cart']={}
          
        
        
        return redirect('cart')
    
    
        
        