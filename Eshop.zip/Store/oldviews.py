
from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models.product import Product
from .models.category import Category
from.models.customer import Customer
from django.contrib.auth.hashers import make_password,check_password

# Create your views here.

def home(request):
    #allproduct=Product.get_all_data()
    allcategory=Category.all_category_list()
    categoryID=request.GET.get('category')
    print(categoryID)
    
    if categoryID:
        allproduct=Product.get_all_data_by_categoryid(categoryID)
    else:
        allproduct=Product.get_all_data()
   
    
    
    return render(request,"index.html",{'products':allproduct,'categorys':allcategory})


def registrasion(request):   
        firstname=request.POST.get('fname')
        lastname=request.POST.get('lname')
        email=request.POST.get('email')
        phone=request.POST.get('phone')
        password=request.POST.get('password')
        
        values={'firstname':firstname,
                'lastname':lastname,
                'email':email,
                'phone':phone,
                }
        customer=Customer(first_name=firstname,last_name=lastname,email=email,phone=phone,password=password)
        error_message=validation_customer(customer)
        
        
        print(error_message)
        
        if  not error_message:
            
        
            
            #customer.save()
            
            customer.password=make_password(customer.password)
            customer.register()
            success_message="Account sucessfull Created!!"
            return render(request,'signup.html',{'message':success_message})
        else:
            
            return render(request,'signup.html',{'error':error_message,'value':values})
        
def validation_customer(customer):
    #validation
        error_message=None
        if not customer.first_name:
            error_message="First name Required!!"
        elif len(customer.first_name)<4:
            error_message="First name must be long 4 char and above"
        elif not customer.last_name:
            error_message="Last Name Required!!"
        elif len(customer.last_name)<4:
            error_message="Last name must be long 4 char and above"
            
            
        elif not customer.email:
            error_message="Email Required!!"
        elif not customer.phone:
            error_message="Phone Required!!"
        elif len(customer.phone)<10:
            error_message="phone must be long 10 digits and above"
        elif not customer.password:
            error_message="Password  Required!!"
        elif len(customer.password)<8:
            error_message="Password must be long 8 char and above"
        elif customer.is_exist():
            print(customer.is_exist())
            error_message="Email address Already exist!!"
        return error_message
                  

def signup(request):
    if request.method =="GET":
        
     return render (request,"signup.html")
    else:
        return registrasion(request)
      
def loginpost(request):  
    email=request.POST.get('email') 
    password=request.POST.get('password')
    user=Customer.customer_data_by_email(email)
    #user1=Customer.objects.filter(email=email)
    error_message=None
    if user.exists():
        customer=user[0]
        password=check_password(password,customer.password)
        if password==True:
            return redirect('home')
        else:
            print("wrong password")
            error_message="Invaild User Or Password|"
            return render(request,'login.html',{'error':error_message})
            
        
        
    else:
        print("no user")
        error_message="Invaild User Or Password!"
        return render(request,'login.html',{'error':error_message})
    
   

    
      
      
def login(request):
    
   if request.method =="GET":
        
     return render (request,"login.html")
   else:
        return loginpost(request)
    
     
    
